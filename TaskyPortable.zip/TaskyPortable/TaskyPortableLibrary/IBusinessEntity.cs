using System;

namespace Tasky.BL.Contracts {
	public interface IBusinessEntity {
		int ID { get; set; }
	}
}

