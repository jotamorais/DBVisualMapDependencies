Tasky Portable
==============

Tasky is a simple cross-platform todo/task application sample that allows
you to track todo items (tasks).

This version uses a *Portable Class Library* to encapsulate and share code across iOS, Android and Windows Phone platforms.

![screenshot](https://raw.github.com/xamarin/mobile-samples/master/TaskyPortable/Screenshots/devices.png) 

**Be warned that if you open the solution in Xamarin Studio it will not be able to load the Windows Phone project.**

Authors
-------

Bryan Costanich, Craig Dunn
